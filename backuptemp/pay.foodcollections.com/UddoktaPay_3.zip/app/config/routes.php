<?php
defined('BASEPATH') or exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/

include_once "route_slugs.php";
$r_login = $custom_slug_array["login"];

$route['default_controller']                = 'home_controller';
$route['404_override']                      = 'home_controller/not_found';
$route['translate_uri_dashes']              = FALSE;

// home section
$route['verify-license']['get']             = 'home_controller/verify_license';
$route['verify-license-post']['post']       = 'home_controller/verify_license_post';
$route['invoice/(:any)']['get']             = 'home_controller/invoice_page/$1';
$route['change-language']['post']           = 'home_controller/chnage_language';
$route['resellercamp/(:any)']['get']        = 'payment_controller/resellercamp/$1';

// admin section
$route['admin/dashboard']                   = 'admin_controller/dashboard';
$route['admin/activities']                  = 'admin_controller/activities';
$route['admin/get-activities']              = 'admin_controller/get_activities';
$route['admin/api-key']                     = 'admin_controller/generate_api_key';
$route['admin/apk-api-key']                 = 'admin_controller/generate_apk_api_key';
$route['admin/invoice-api-key']             = 'admin_controller/generate_invoice_api_key';
$route['admin/profile']                     = 'admin_controller/profile_settings';
$route['admin/profile-post']                = 'admin_controller/profile_settings_post';

// Upload
$route['upload/profile-picture']['post']            = 'admin_controller/upload_profile_picture';
$route['upload/qr-code/(:any)']['post']             = 'admin_controller/upload_qr_code/$1';
$route['upload/bkash-logo']['post']                 = 'admin_controller/upload_bkash_logo';
$route['upload/nagad-logo']['post']                 = 'admin_controller/upload_nagad_logo';
$route['upload/logo']['post']                       = 'admin_controller/upload_logo';
$route['upload/favicon']['post']                    = 'admin_controller/upload_favicon';
$route['upload/invoice-logo']['post']               = 'admin_controller/upload_invoice_logo';
$route['upload/invoice-banner']['post']             = 'admin_controller/upload_invoice_banner';
$route['upload/upload-bank-logo']['post']           = 'admin_controller/upload_bank_logo';
$route['upload/payment-slip']['post']               = 'payment_controller/upload_payment_slip';
$route['upload/fb-og-image']['post']                = 'admin_controller/fb_og_image';
$route['upload/twitter-og-image']['post']           = 'admin_controller/twitter_og_image';

// payment section
$route['admin/payments']                    = 'admin_controller/payments';
$route['admin/get-payments']                = 'admin_controller/get_payments';
$route['admin/pending-payments']            = 'admin_controller/pending_payments';
$route['admin/get-pending-payments']        = 'admin_controller/get_pending_payments';
$route['admin/refunded-payments']           = 'admin_controller/refunded_payments';
$route['admin/get-refunded-payments']       = 'admin_controller/get_refunded_payments';
$route['admin/trash-payments']              = 'admin_controller/trash_payments';
$route['admin/get-trash-payments']          = 'admin_controller/get_trash_payments';

// bank payment
$route['admin/bank-payments']               = 'admin_controller/bank_payments';
$route['admin/get-bank-payments']           = 'admin_controller/get_bank_payments';
$route['admin/pending-bank-payments']       = 'admin_controller/pending_bank_payments';
$route['admin/get-pending-bank-payments']   = 'admin_controller/get_pending_bank_payments';
$route['admin/refunded-bank-payments']      = 'admin_controller/refunded_bank_payments';
$route['admin/get-refunded-bank-payments']  = 'admin_controller/get_refunded_bank_payments';
$route['admin/trash-bank-payments']         = 'admin_controller/trash_bank_payments';
$route['admin/get-trash-bank-payments']     = 'admin_controller/get_trash_bank_payments';


// stored data
$route['admin/stored-data']                 = 'admin_controller/stored_data';
$route['admin/get-stored-data']             = 'admin_controller/get_stored_data';
$route['admin/add-stored-data']             = 'admin_controller/add_stored_data';
$route['admin/add-stored-data-post']        = 'admin_controller/add_stored_data_post';
$route['admin/trash-stored-data']           = 'admin_controller/trash_stored_data';
$route['admin/get-trash-stored-data']       = 'admin_controller/get_trash_stored_data';


// payment function
$route['admin/mark-as-used']                = 'admin_controller/mark_as_used_with_webhook_request';
$route['admin/send-webhook-request']        = 'admin_controller/send_webhook_request';
$route['admin/payment-status']              = 'admin_controller/payment_status';
$route['admin/bank-payment-status']         = 'admin_controller/bank_payment_status';
$route['admin/refund-payment']              = 'admin_controller/refund_payment';

//settings section
$route['admin/general-settings']            = 'admin_controller/general_settings';
$route['admin/general-settings-post']       = 'admin_controller/general_settings_post';
$route['admin/meta-settings']               = 'admin_controller/meta_settings';
$route['admin/api-settings']                = 'admin_controller/api_settings';

// payment settings
$route['admin/payment/bkash']               = 'admin_controller/bkash_settings';
$route['admin/payment/rocket']              = 'admin_controller/rocket_settings';
$route['admin/payment/nagad']               = 'admin_controller/nagad_settings';
$route['admin/payment/upay']                = 'admin_controller/upay_settings';
$route['admin/payment/cellfin']             = 'admin_controller/cellfin_settings';
$route['admin/payment/bkash-post']          = 'admin_controller/bkash_settings_post';
$route['admin/payment/rocket-post']         = 'admin_controller/rocket_settings_post';
$route['admin/payment/nagad-post']          = 'admin_controller/nagad_settings_post';
$route['admin/payment/upay-post']           = 'admin_controller/upay_settings_post';
$route['admin/payment/cellfin-post']        = 'admin_controller/cellfin_settings_post';
$route['admin/payment/bank']                = 'admin_controller/bank_settings';

// bank section
$route['admin/manage-bank']                  = 'admin_controller/bank_list';
$route['admin/add-bank']                     = 'admin_controller/add_bank';
$route['admin/add-bank-post']                = 'admin_controller/add_bank_post';
$route['admin/edit-bank/(:num)']             = 'admin_controller/edit_bank/$1';
$route['admin/edit-bank-post']               = 'admin_controller/edit_bank_post';

// resellerclub section
$route['admin/manage-resellerclub-api']       = 'admin_controller/resellerclub_api_list';
$route['admin/add-resellerclub-api']          = 'admin_controller/add_resellerclub_api';
$route['admin/add-resellerclub-api-post']     = 'admin_controller/add_resellerclub_api_post';
$route['admin/edit-resellerclub-api/(:num)']  = 'admin_controller/edit_resellerclub_api/$1';
$route['admin/edit-resellerclub-api-post']    = 'admin_controller/edit_resellerclub_api_post';

// resellercamp section
$route['admin/manage-resellercamp-api']       = 'admin_controller/resellercamp_api_list';
$route['admin/add-resellercamp-api']          = 'admin_controller/add_resellercamp_api';
$route['admin/add-resellercamp-api-post']     = 'admin_controller/add_resellercamp_api_post';
$route['admin/edit-resellercamp-api/(:num)']  = 'admin_controller/edit_resellercamp_api/$1';
$route['admin/edit-resellercamp-api-post']    = 'admin_controller/edit_resellercamp_api_post';


// Other Settings
$route['admin/mail-settings']               = 'admin_controller/mail_settings';
$route['admin/test-mail']                   = 'admin_controller/test_mail';
$route['admin/cron-settings']               = 'admin_controller/cron_settings';
$route['admin/active-domain-license']       = 'admin_controller/active_domain_license';
$route['admin/active-domain-license-post']  = 'admin_controller/active_domain_license_post';
$route['admin/notification/onesignal']      = 'admin_controller/onesignal_notification';
$route['admin/notification/email']          = 'admin_controller/email_notification';
$route['admin/change-password']             = 'admin_controller/change_password';
$route['admin/change-password-post']        = 'admin_controller/change_password_post';
$route['admin/check-updates']               = 'admin_controller/check_updates';

// trash section
$route['admin/trash-item']                  = 'admin_controller/trash_item';
$route['admin/trash-multi-items']           = 'admin_controller/trash_multi_items';

// delete section
$route['admin/delete-item']                 = 'admin_controller/delete_item';
$route['admin/delete-multi-items']          = 'admin_controller/delete_multi_items';

// restore_item
$route['admin/restore-item']                = 'admin_controller/restore_item';

// update section
$route['admin/update-settings']             = 'admin_controller/update_settings';

// invoice section
$route['admin/manage-invoice']              = 'admin_controller/invoice_list';
$route['admin/invoice-link']                = 'admin_controller/invoice_link';
$route['admin/add-invoice']                 = 'admin_controller/add_invoice';
$route['admin/add-invoice-post']            = 'admin_controller/add_invoice_post';
$route['admin/edit-invoice/(:num)']         = 'admin_controller/edit_invoice/$1';
$route['admin/edit-invoice-post']           = 'admin_controller/edit_invoice_post';

// faq section
$route['admin/manage-faq']                  = 'admin_controller/faq_list';
$route['admin/add-faq']                     = 'admin_controller/add_faq';
$route['admin/add-faq-post']                = 'admin_controller/add_faq_post';
$route['admin/edit-faq/(:num)']             = 'admin_controller/edit_faq/$1';
$route['admin/edit-faq-post']               = 'admin_controller/edit_faq_post';

// auth
$route[$r_login]                            = 'auth_controller/login';
$route['login-post']['post']                = 'auth_controller/login_post';
$route['admin/logout']                      = 'auth_controller/logout';
$route['forgot-password']['get']            = 'auth_controller/forgot_password';
$route['forgot-password-post']['post']      = 'auth_controller/forgot_password_post';
$route['reset-password']['get']             = 'auth_controller/reset_password';
$route['reset-password-post']['post']       = 'auth_controller/reset_password_post';

// callback
$route['callback/(:any)']['post']           = 'callback_controller/callback_data/$1';

// cron section
$route['cron/run']                          = 'cron/run';

// payment controller
$route['resellercamp-add-fund']['post']             = 'payment_controller/resellercamp_api';
$route['generate-invoice']['post']                  = 'payment_controller/invoice_api';
$route['payment/(:any)']['get']                     = 'payment_controller/payment_page/$1';
$route['checkout/mobile/(:any)/(:any)']['get']      = 'payment_controller/mobile_bank/$1/$2';
$route['checkout/bank/(:any)/(:any)']['get']        = 'payment_controller/net_bank/$1/$2';
$route['checkout/success']['post']                  = 'payment_controller/success_page';
$route['checkout/cancel']                           = 'payment_controller/cancel_page';

// external api section
$route['api/checkout']['post']                      = 'api_controller/add_temp_data';
$route['api/checkout-v2']['post']                   = 'api_controller/add_temp_data_v2';
$route['api/domain-checkout/(:any)']['get']         = 'api_controller/add_temp_domain_data/$1';
$route['api/verify-payment']['post']                = 'api_controller/verify_payment_transaction';
$route['api/verify-payment/(:any)']['post']         = 'api_controller/verify_payment_transaction/$1';
$route['api/refund-payment']['post']                = 'api_controller/refund_payment';

// internal api controller
$route['checkout/verify-payment-data']['post']      = 'payment_api_controller/init_api';
$route['checkout/verify-bank-data']['post']         = 'payment_controller/submit_bank_payment';
$route['checkout/payment/bkash']['post']            = 'bkash_api_controller/init_bkash';
$route['checkout/payment/nagad/(:any)']['get']      = 'nagad_api_controller/init_nagad/$1';
$route['nagad/callback']                            = 'nagad_api_controller/verify';
$route['checkout/payment/upay/(:any)']['get']       = 'upay_api_controller/init_upay/$1';
$route['upay/callback']                             = 'upay_api_controller/verify';